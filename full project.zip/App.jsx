import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

// Import all pages
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import SignUpPage from './pages/SignUpPage';
import RestaurantsPage from './pages/RestaurantsPage';
import BusinessDetailPage from './pages/BusinessDetailPage';
import UserProfilePage from './pages/UserProfilePage';
import WriteReviewPage from './pages/WriteReviewPage';
import AdminDashboard from './pages/AdminDashboard';
import BusinessOwnerDashboard from './pages/BusinessOwnerDashboard';
import ProjectsPage from './pages/ProjectsPage';
import GuaranteePage from './pages/GuaranteePage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignUpPage />} />
        <Route path="/restaurants" element={<RestaurantsPage />} />
        <Route path="/spa" element={<RestaurantsPage category="spa" />} />
        <Route path="/cleaning" element={<RestaurantsPage category="cleaning" />} />
        <Route path="/auto-services" element={<RestaurantsPage category="auto" />} />
        <Route path="/business/:id" element={<BusinessDetailPage />} />
        <Route path="/business/:id/review" element={<WriteReviewPage />} />
        <Route path="/profile/:id" element={<UserProfilePage />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/business-owner" element={<BusinessOwnerDashboard />} />
        <Route path="/projects" element={<ProjectsPage />} />
        <Route path="/guarantee" element={<GuaranteePage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
